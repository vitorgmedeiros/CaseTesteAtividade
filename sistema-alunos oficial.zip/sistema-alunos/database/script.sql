-- ==========================================
-- Sistema de Gestao de Alunos
-- Execute este script no MySQL antes de iniciar o backend
-- ==========================================

CREATE DATABASE IF NOT EXISTS sistema_alunos
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE sistema_alunos;

-- ==========================================
-- Tabela de usuarios (acesso ao sistema)
-- ==========================================

CREATE TABLE IF NOT EXISTS usuarios (
    id BIGINT NOT NULL AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(100) NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_usuarios_username (username)
);

-- ==========================================
-- Tabela de alunos
-- ==========================================

CREATE TABLE IF NOT EXISTS alunos (
    id BIGINT NOT NULL AUTO_INCREMENT,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    cpf VARCHAR(14) NOT NULL,
    curso VARCHAR(100) NOT NULL,
    idade INT NOT NULL,
    ativo BOOLEAN NOT NULL,
    data_cadastro DATETIME NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uk_alunos_email (email),
    UNIQUE KEY uk_alunos_cpf (cpf)
);

-- ==========================================
-- Usuario para teste
-- username: admin
-- senha: 123456
-- (a senha fica salva somente como hash BCrypt)
-- ==========================================

INSERT INTO usuarios (username, password)
VALUES ('admin', '$2a$10$KJgm0dcr0nsB857uckimL.6HHVJHd8Ow1Cok4jCOcW2oi3NtFpBFq')
ON DUPLICATE KEY UPDATE username = username;
