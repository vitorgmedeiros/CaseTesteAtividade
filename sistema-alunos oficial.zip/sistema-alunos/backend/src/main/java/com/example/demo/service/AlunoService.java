package com.example.demo.service;

import com.example.demo.dto.AlunoRequestDTO;
import com.example.demo.dto.AlunoResponseDTO;
import com.example.demo.exception.AlunoNaoEncontradoException;
import com.example.demo.exception.CpfJaCadastradoException;
import com.example.demo.exception.EmailJaCadastradoException;
import com.example.demo.model.Aluno;
import com.example.demo.repository.AlunoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class AlunoService {

    private final AlunoRepository alunoRepository;

    public AlunoService(AlunoRepository alunoRepository) {
        this.alunoRepository = alunoRepository;
    }

    public List<AlunoResponseDTO> listar() {

        return alunoRepository.findAll()
                .stream()
                .map(AlunoResponseDTO::new)
                .toList();
    }

    public AlunoResponseDTO buscarPorId(Long id) {

        Aluno aluno = alunoRepository.findById(id)
                .orElseThrow(() -> new AlunoNaoEncontradoException(id));

        return new AlunoResponseDTO(aluno);
    }

    @Transactional
    public AlunoResponseDTO criar(AlunoRequestDTO dto) {

        if (alunoRepository.existsByEmail(dto.getEmail())) {
            throw new EmailJaCadastradoException();
        }

        if (alunoRepository.existsByCpf(dto.getCpf())) {
            throw new CpfJaCadastradoException();
        }

        Aluno aluno = new Aluno();
        preencherAluno(aluno, dto);

        Aluno alunoSalvo = alunoRepository.save(aluno);

        return new AlunoResponseDTO(alunoSalvo);
    }

    @Transactional
    public AlunoResponseDTO atualizar(Long id, AlunoRequestDTO dto) {

        Aluno aluno = alunoRepository.findById(id)
                .orElseThrow(() -> new AlunoNaoEncontradoException(id));

        // Verifica duplicidade ignorando o proprio aluno
        if (alunoRepository.existsByEmailAndIdNot(dto.getEmail(), id)) {
            throw new EmailJaCadastradoException();
        }

        if (alunoRepository.existsByCpfAndIdNot(dto.getCpf(), id)) {
            throw new CpfJaCadastradoException();
        }

        preencherAluno(aluno, dto);

        Aluno alunoAtualizado = alunoRepository.save(aluno);

        return new AlunoResponseDTO(alunoAtualizado);
    }

    @Transactional
    public void excluir(Long id) {

        if (!alunoRepository.existsById(id)) {
            throw new AlunoNaoEncontradoException(id);
        }

        alunoRepository.deleteById(id);
    }

    // Copia os dados do DTO para a entidade
    private void preencherAluno(Aluno aluno, AlunoRequestDTO dto) {

        aluno.setNome(dto.getNome());
        aluno.setEmail(dto.getEmail());
        aluno.setCpf(dto.getCpf());
        aluno.setCurso(dto.getCurso());
        aluno.setIdade(dto.getIdade());
        aluno.setAtivo(dto.getAtivo());
    }
}
