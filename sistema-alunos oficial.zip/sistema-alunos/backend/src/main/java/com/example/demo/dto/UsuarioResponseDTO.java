package com.example.demo.dto;

// Dados do usuario devolvidos pela API (nunca possui password)
public class UsuarioResponseDTO {

    private String username;

    public UsuarioResponseDTO() {
    }

    public UsuarioResponseDTO(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }
}
