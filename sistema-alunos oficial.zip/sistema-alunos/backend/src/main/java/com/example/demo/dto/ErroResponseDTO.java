package com.example.demo.dto;

import java.util.HashMap;
import java.util.Map;

// Formato padrao das respostas de erro da API
public class ErroResponseDTO {

    private String mensagem;

    // Erros por campo (usado nas validacoes). Vazio nos demais erros.
    private Map<String, String> erros = new HashMap<>();

    public ErroResponseDTO() {
    }

    public ErroResponseDTO(String mensagem) {
        this.mensagem = mensagem;
    }

    public ErroResponseDTO(String mensagem, Map<String, String> erros) {
        this.mensagem = mensagem;
        this.erros = erros;
    }

    public String getMensagem() {
        return mensagem;
    }

    public Map<String, String> getErros() {
        return erros;
    }
}
