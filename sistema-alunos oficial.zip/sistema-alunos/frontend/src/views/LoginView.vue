<template>

  <div class="login">

    <h1>Sistema de Gestão de Alunos</h1>

    <h2>Login</h2>

    <p v-if="mensagemErro" class="mensagem erro">
      {{ mensagemErro }}
    </p>

    <form @submit.prevent="entrar">

      <label for="usuario">Usuário</label>
      <input
        id="usuario"
        v-model="usuario"
        type="text"
        placeholder="Usuário"
      />

      <label for="senha">Senha</label>
      <input
        id="senha"
        v-model="senha"
        type="password"
        placeholder="Senha"
      />

      <button type="submit" :disabled="carregando">
        {{ carregando ? "Entrando..." : "Entrar" }}
      </button>

    </form>

  </div>

</template>


<script>

import { login } from '../services/api.js'

export default {

  data() {

    return {

      usuario: "",

      senha: "",

      mensagemErro: "",

      carregando: false

    }

  },


  methods: {

    // ==========================================
    // LOGIN
    // ==========================================

    async entrar() {

      this.mensagemErro = "";

      this.carregando = true;

      const resposta = await login(this.usuario, this.senha);

      this.carregando = false;

      if (resposta.ok) {

        sessionStorage.setItem('logado', 'true');

        this.$router.push('/alunos');

        return;

      }

      if (resposta.status === 401) {

        this.mensagemErro = "Usuário ou senha inválidos.";

      } else if (resposta.status === 400) {

        this.mensagemErro = "Informe o usuário e a senha.";

      } else if (resposta.dados && resposta.dados.mensagem) {

        this.mensagemErro = resposta.dados.mensagem;

      } else {

        this.mensagemErro = "Não foi possível realizar o login.";

      }

    }

  }

}

</script>
