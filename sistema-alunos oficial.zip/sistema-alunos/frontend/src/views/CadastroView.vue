<template>

  <div>

    <h1>Cadastrar aluno</h1>

    <AlunoForm
      textoBotao="Cadastrar"
      :salvando="salvando"
      :mensagemErro="mensagemErro"
      :erros="erros"
      @salvar="cadastrar"
      @cancelar="voltar"
    />

  </div>

</template>


<script>

import AlunoForm from '../components/AlunoForm.vue'
import { cadastrarAluno } from '../services/api.js'

export default {

  components: { AlunoForm },


  data() {

    return {

      salvando: false,

      mensagemErro: "",

      erros: {}

    }

  },


  methods: {

    // ==========================================
    // POST
    // ==========================================

    async cadastrar(dados) {

      this.salvando = true;

      this.mensagemErro = "";

      this.erros = {};

      const resposta = await cadastrarAluno(dados);

      this.salvando = false;

      if (resposta.ok) {

        sessionStorage.setItem(
          'mensagemSucesso',
          'Aluno cadastrado com sucesso.'
        );

        this.$router.push('/alunos');

        return;

      }

      // 400 = dados invalidos | 409 = e-mail ou CPF ja cadastrado

      if (resposta.dados) {

        this.mensagemErro = resposta.dados.mensagem || "Não foi possível cadastrar o aluno.";

        this.erros = resposta.dados.erros || {};

      } else {

        this.mensagemErro = "Não foi possível cadastrar o aluno.";

      }

    },

    voltar() {

      this.$router.push('/alunos');

    }

  }

}

</script>
