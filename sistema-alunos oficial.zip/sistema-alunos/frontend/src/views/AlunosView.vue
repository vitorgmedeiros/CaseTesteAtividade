<template>

  <div>

    <div class="topo">

      <h1>Alunos</h1>

      <div>

        <button @click="irParaCadastro">
          Cadastrar aluno
        </button>

        <button class="secundario" @click="sair">
          Sair
        </button>

      </div>

    </div>

    <p v-if="mensagemSucesso" class="mensagem sucesso">
      {{ mensagemSucesso }}
    </p>

    <p v-if="mensagemErro" class="mensagem erro">
      {{ mensagemErro }}
    </p>

    <p v-if="carregando">Carregando...</p>

    <p v-else-if="alunos.length === 0">
      Nenhum aluno cadastrado.
    </p>

    <table v-else>

      <thead>
        <tr>
          <th>ID</th>
          <th>Nome</th>
          <th>E-mail</th>
          <th>CPF</th>
          <th>Curso</th>
          <th>Idade</th>
          <th>Ativo</th>
          <th>Data de cadastro</th>
          <th>Ações</th>
        </tr>
      </thead>

      <tbody>

        <tr
          v-for="aluno in alunos"
          :key="aluno.id"
        >

          <td>{{ aluno.id }}</td>
          <td>{{ aluno.nome }}</td>
          <td>{{ aluno.email }}</td>
          <td>{{ aluno.cpf }}</td>
          <td>{{ aluno.curso }}</td>
          <td>{{ aluno.idade }}</td>
          <td>{{ aluno.ativo ? "Sim" : "Não" }}</td>
          <td>{{ formatarData(aluno.dataCadastro) }}</td>

          <td>

            <button @click="editarAluno(aluno)">
              Editar
            </button>

            <button class="perigo" @click="deletarAluno(aluno)">
              Excluir
            </button>

          </td>

        </tr>

      </tbody>

    </table>

  </div>

</template>


<script>

import { listarAlunos, excluirAluno, logout } from '../services/api.js'

export default {

  data() {

    return {

      alunos: [],

      carregando: false,

      mensagemSucesso: "",

      mensagemErro: ""

    }

  },


  methods: {

    // ==========================================
    // GET
    // ==========================================

    async buscarAlunos() {

      this.carregando = true;

      const resposta = await listarAlunos();

      this.carregando = false;

      if (resposta.ok) {

        this.alunos = resposta.dados;

      } else {

        this.mensagemErro = "Não foi possível carregar os alunos.";

      }

    },


    // ==========================================
    // NAVEGACAO
    // ==========================================

    irParaCadastro() {

      this.$router.push('/alunos/novo');

    },

    editarAluno(aluno) {

      this.$router.push(`/alunos/${aluno.id}/editar`);

    },


    // ==========================================
    // DELETE
    // ==========================================

    async deletarAluno(aluno) {

      // Pergunta antes de excluir

      const confirmar =
        confirm(
          `Tem certeza que deseja excluir o aluno ${aluno.nome}?`
        );

      if (!confirmar) {

        return;

      }

      this.mensagemSucesso = "";

      this.mensagemErro = "";

      const resposta = await excluirAluno(aluno.id);

      if (resposta.ok) {

        // Remove o aluno da lista da pagina

        this.alunos =
          this.alunos.filter(
            a => a.id !== aluno.id
          );

        this.mensagemSucesso = "Aluno excluído com sucesso.";

      } else if (resposta.status === 404) {

        this.mensagemErro = "Aluno não encontrado.";

        this.buscarAlunos();

      } else {

        this.mensagemErro = "Não foi possível excluir o aluno.";

      }

    },


    // ==========================================
    // SAIR
    // ==========================================

    async sair() {

      await logout();

      sessionStorage.removeItem('logado');

      this.$router.push('/login');

    },


    // ==========================================
    // FORMATA A DATA (dd/mm/aaaa hh:mm)
    // ==========================================

    formatarData(data) {

      if (!data) {

        return "";

      }

      return new Date(data).toLocaleString('pt-BR');

    }

  },


  // ==========================================
  // EXECUTADO AO ABRIR A PAGINA
  // ==========================================

  mounted() {

    // Mensagem deixada pelas telas de cadastro/edicao

    const mensagem = sessionStorage.getItem('mensagemSucesso');

    if (mensagem) {

      this.mensagemSucesso = mensagem;

      sessionStorage.removeItem('mensagemSucesso');

    }

    this.buscarAlunos();

  }

}

</script>
