<template>

  <div>

    <h1>Editar aluno</h1>

    <p v-if="carregando">Carregando...</p>

    <p v-if="mensagemErro && !aluno" class="mensagem erro">
      {{ mensagemErro }}
    </p>

    <AlunoForm
      v-if="aluno"
      :alunoInicial="aluno"
      textoBotao="Salvar alteração"
      :salvando="salvando"
      :mensagemErro="mensagemErro"
      :erros="erros"
      @salvar="atualizar"
      @cancelar="voltar"
    />

    <button v-if="!aluno && !carregando" class="secundario" @click="voltar">
      Voltar
    </button>

  </div>

</template>


<script>

import AlunoForm from '../components/AlunoForm.vue'
import { buscarAluno, atualizarAluno } from '../services/api.js'

export default {

  components: { AlunoForm },


  data() {

    return {

      aluno: null,

      carregando: false,

      salvando: false,

      mensagemErro: "",

      erros: {}

    }

  },


  methods: {

    // ==========================================
    // GET (busca o aluno pelo ID)
    // ==========================================

    async carregarAluno() {

      this.carregando = true;

      const resposta = await buscarAluno(this.$route.params.id);

      this.carregando = false;

      if (resposta.ok) {

        this.aluno = resposta.dados;

      } else if (resposta.status === 404) {

        this.mensagemErro = "Aluno não encontrado.";

      } else {

        this.mensagemErro = "Não foi possível carregar o aluno.";

      }

    },


    // ==========================================
    // PUT
    // ==========================================

    async atualizar(dados) {

      this.salvando = true;

      this.mensagemErro = "";

      this.erros = {};

      const resposta = await atualizarAluno(this.$route.params.id, dados);

      this.salvando = false;

      if (resposta.ok) {

        sessionStorage.setItem(
          'mensagemSucesso',
          'Aluno atualizado com sucesso.'
        );

        this.$router.push('/alunos');

        return;

      }

      // 400 = dados invalidos | 404 = nao encontrado | 409 = e-mail ou CPF ja cadastrado

      if (resposta.dados) {

        this.mensagemErro = resposta.dados.mensagem || "Não foi possível atualizar o aluno.";

        this.erros = resposta.dados.erros || {};

      } else {

        this.mensagemErro = "Não foi possível atualizar o aluno.";

      }

    },

    voltar() {

      this.$router.push('/alunos');

    }

  },


  mounted() {

    this.carregarAluno();

  }

}

</script>
