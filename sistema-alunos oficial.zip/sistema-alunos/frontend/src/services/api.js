const URL_API = 'http://localhost:8081/api'


// ==========================================
// REQUISICAO PADRAO
// ==========================================
// Envia o cookie da sessao (credentials) e devolve
// { ok, status, dados } para as telas tratarem.

async function requisicao(caminho, opcoes = {}) {

  const configuracao = {

    method: opcoes.method || 'GET',

    credentials: 'include',

    headers: {
      'Content-Type': 'application/json'
    }

  }

  if (opcoes.body !== undefined) {
    configuracao.body = JSON.stringify(opcoes.body)
  }

  let resposta

  try {

    resposta = await fetch(URL_API + caminho, configuracao)

  } catch (erro) {

    console.error('Erro de conexão com a API:', erro)

    return {
      ok: false,
      status: 0,
      dados: { mensagem: 'Não foi possível conectar ao servidor.', erros: {} }
    }

  }

  console.log('Status de', configuracao.method, caminho, ':', resposta.status)

  // 204 (No Content) nao possui corpo
  let dados = null

  if (resposta.status !== 204) {

    try {
      dados = await resposta.json()
    } catch (erro) {
      dados = null
    }

  }

  // Sessao expirada / nao autenticado: volta para o login
  // (o login em si tambem responde 401 quando a senha esta errada)
  if (resposta.status === 401 && !opcoes.semRedirecionar) {

    sessionStorage.removeItem('logado')

    window.location.href = '/login'

  }

  return {
    ok: resposta.ok,
    status: resposta.status,
    dados: dados
  }

}


// ==========================================
// AUTENTICACAO
// ==========================================

export function login(username, password) {

  return requisicao('/login', {
    method: 'POST',
    body: { username, password },
    semRedirecionar: true
  })

}

export function logout() {

  return requisicao('/logout', {
    method: 'POST',
    semRedirecionar: true
  })

}


// ==========================================
// ALUNOS
// ==========================================

export function listarAlunos() {
  return requisicao('/alunos')
}

export function buscarAluno(id) {
  return requisicao(`/alunos/${id}`)
}

export function cadastrarAluno(aluno) {
  return requisicao('/alunos', { method: 'POST', body: aluno })
}

export function atualizarAluno(id, aluno) {
  return requisicao(`/alunos/${id}`, { method: 'PUT', body: aluno })
}

export function excluirAluno(id) {
  return requisicao(`/alunos/${id}`, { method: 'DELETE' })
}
