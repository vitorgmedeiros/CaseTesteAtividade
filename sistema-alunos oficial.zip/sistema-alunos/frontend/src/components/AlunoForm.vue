<template>

  <form novalidate @submit.prevent="enviar">

    <p v-if="mensagemErro" class="mensagem erro">
      {{ mensagemErro }}
    </p>

    <!-- Nome -->
    <label for="nome">Nome</label>
    <input
      id="nome"
      v-model="aluno.nome"
      type="text"
      placeholder="Nome"
    />
    <span v-if="erros.nome" class="erro-campo">{{ erros.nome }}</span>

    <!-- E-mail -->
    <label for="email">E-mail</label>
    <input
      id="email"
      v-model="aluno.email"
      type="email"
      placeholder="E-mail"
    />
    <span v-if="erros.email" class="erro-campo">{{ erros.email }}</span>

    <!-- CPF -->
    <label for="cpf">CPF</label>
    <input
      id="cpf"
      v-model="aluno.cpf"
      type="text"
      placeholder="CPF"
    />
    <span v-if="erros.cpf" class="erro-campo">{{ erros.cpf }}</span>

    <!-- Curso -->
    <label for="curso">Curso</label>
    <input
      id="curso"
      v-model="aluno.curso"
      type="text"
      placeholder="Curso"
    />
    <span v-if="erros.curso" class="erro-campo">{{ erros.curso }}</span>

    <!-- Idade -->
    <label for="idade">Idade</label>
    <input
      id="idade"
      v-model="aluno.idade"
      type="number"
      placeholder="Idade"
    />
    <span v-if="erros.idade" class="erro-campo">{{ erros.idade }}</span>

    <!-- Ativo -->
    <label class="linha">
      <input
        v-model="aluno.ativo"
        type="checkbox"
      />
      Aluno ativo
    </label>
    <span v-if="erros.ativo" class="erro-campo">{{ erros.ativo }}</span>

    <div class="acoes">

      <button type="submit" :disabled="salvando">
        {{ salvando ? "Salvando..." : textoBotao }}
      </button>

      <button
        type="button"
        class="secundario"
        @click="$emit('cancelar')"
      >
        Cancelar
      </button>

    </div>

  </form>

</template>


<script>

export default {

  props: {

    // Dados iniciais do aluno (vazio no cadastro, preenchido na edicao)
    alunoInicial: {
      type: Object,
      default: () => ({
        nome: "",
        email: "",
        cpf: "",
        curso: "",
        idade: null,
        ativo: true
      })
    },

    textoBotao: {
      type: String,
      default: "Salvar"
    },

    salvando: {
      type: Boolean,
      default: false
    },

    // Mensagem geral de erro (ex.: e-mail ja cadastrado)
    mensagemErro: {
      type: String,
      default: ""
    },

    // Erros por campo vindos da API (400)
    erros: {
      type: Object,
      default: () => ({})
    }

  },

  emits: ['salvar', 'cancelar'],


  data() {

    return {

      aluno: { ...this.alunoInicial }

    }

  },


  methods: {

    enviar() {

      // Monta o objeto que sera enviado para a API

      const dados = {

        nome: this.aluno.nome,

        email: this.aluno.email,

        cpf: this.aluno.cpf,

        curso: this.aluno.curso,

        idade: this.aluno.idade === "" || this.aluno.idade === null
          ? null
          : Number(this.aluno.idade),

        ativo: this.aluno.ativo

      };

      this.$emit('salvar', dados);

    }

  }

}

</script>
