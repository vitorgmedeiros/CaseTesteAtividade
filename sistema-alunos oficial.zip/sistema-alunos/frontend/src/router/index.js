import { createRouter, createWebHistory } from 'vue-router'

import LoginView from '../views/LoginView.vue'
import AlunosView from '../views/AlunosView.vue'
import CadastroView from '../views/CadastroView.vue'
import EdicaoView from '../views/EdicaoView.vue'

const router = createRouter({

  history: createWebHistory(),

  routes: [

    { path: '/', redirect: '/alunos' },

    { path: '/login', component: LoginView },

    { path: '/alunos', component: AlunosView, meta: { exigeLogin: true } },

    { path: '/alunos/novo', component: CadastroView, meta: { exigeLogin: true } },

    { path: '/alunos/:id/editar', component: EdicaoView, meta: { exigeLogin: true } },

    { path: '/:qualquerCoisa(.*)*', redirect: '/alunos' }

  ]

})


// ==========================================
// PROTEGE AS TELAS
// ==========================================
// A protecao de verdade esta no backend (Spring Security).
// Aqui apenas evitamos abrir telas sem estar logado.

router.beforeEach((destino) => {

  const logado = sessionStorage.getItem('logado') === 'true'

  if (destino.meta.exigeLogin && !logado) {
    return '/login'
  }

  if (destino.path === '/login' && logado) {
    return '/alunos'
  }

})

export default router
